import psycopg2

def safe_fetch(cur):
    """Safely fetch a single value from SQL query."""
    row = cur.fetchone()
    if row is None:
        return 0
    if row[0] is None:
        return 0
    return row[0]

def validate():
    print("Running validations...")

    conn = psycopg2.connect(
        host="localhost",
        database="workshop",
        user="postgres",
        password="postgres"
    )
    cur = conn.cursor()

    # 1️⃣ Count total records
    cur.execute("SELECT COUNT(*) FROM hcpcs_codes;")
    total = safe_fetch(cur)
    print(f"Total HCPCS records in DB: {total}")

    # 2️⃣ Check missing descriptions
    cur.execute("SELECT COUNT(*) FROM hcpcs_codes WHERE description IS NULL OR description = '';")
    missing_desc = safe_fetch(cur)
    print(f"Records missing description: {missing_desc}")

    # 3️⃣ Check missing application
    cur.execute("SELECT COUNT(*) FROM hcpcs_codes WHERE application IS NULL OR application = '';")
    missing_app = safe_fetch(cur)
    print(f"Records missing application: {missing_app}")

    # 4️⃣ Check invalid category
    cur.execute("""
        SELECT COUNT(*) FROM hcpcs_codes 
        WHERE group_code NOT IN ('A','B','C','D','E','F','G','H','J','K','L','M','N','P','Q','R','S','T','V');
    """)
    invalid_cat = safe_fetch(cur)
    print(f"Records with invalid category: {invalid_cat}")

    conn.close()
    print("Validation complete.")
