import psycopg2
import pandas as pd
import os

def load():
    print("Loading into PostgreSQL...")

    df = pd.read_csv("data/processed/hcpcs_clean.csv")

    conn = psycopg2.connect(
        host="localhost",
        database="workshop",
        user="postgres",
        password="postgres"
    )
    cur = conn.cursor()

    # 1️⃣ Create table if not exists
    cur.execute("""
        CREATE TABLE IF NOT EXISTS hcpcs_codes (
            hcpcs_code VARCHAR(10) PRIMARY KEY,
            description TEXT,
            application TEXT,
            group_code VARCHAR(1),
            category_name VARCHAR(20),
            load_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

    # 2️⃣ Upsert data
    for _, row in df.iterrows():
        cur.execute("""
            INSERT INTO hcpcs_codes (hcpcs_code, description, application, group_code, category_name)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (hcpcs_code)
            DO UPDATE SET
                description = EXCLUDED.description,
                application = EXCLUDED.application,
                group_code = EXCLUDED.group_code,
                category_name = EXCLUDED.category_name,
                load_timestamp = CURRENT_TIMESTAMP;
        """, (
            row["hcpcs_code"],
            row["description"],
            row["application"],
            row["group_code"],
            row["category_name"]
        ))

    conn.commit()
    cur.close()
    conn.close()

    print("Load completed successfully.")
