import pandas as pd
import os

def transform(input="data/raw/hcpcs.csv", output="data/processed/hcpcs_clean.csv"):
    df = pd.read_csv(input)

    df.columns = [c.lower().replace(" ", "_") for c in df.columns]

    # Normalize descriptions
    if "long_description" not in df.columns:
        if "description" in df.columns:
            df["long_description"] = df["description"]

    df["long_description"] = df["long_description"].astype(str).str.strip()
    df["hcpcs_code"] = df["hcpcs_code"].astype(str).str.strip()

    df = df[df["hcpcs_code"] != ""]

    os.makedirs(os.path.dirname(output), exist_ok=True)
    df.to_csv(output, index=False)
    print(f"Transformed → {output}")
    return df
