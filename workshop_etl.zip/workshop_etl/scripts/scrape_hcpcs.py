import os
import pandas as pd

def scrape_all(input_csv="data/raw/hcpcs.csv", output="data/raw/hcpcs.csv"):
    if not os.path.exists(input_csv):
        raise FileNotFoundError(f"CSV file not found: {input_csv}")

    print(f"Loading local HCPCS data: {input_csv}")

    df = pd.read_csv(input_csv, dtype=str)

    df.columns = [c.lower().replace(" ", "_") for c in df.columns]

    df["group_code"] = df["hcpcs_code"].astype(str).str[0]
    df["category_name"] = df["group_code"] + "-codes"

    print(f"Extracted {len(df)} rows from local HCPCS dataset.")
    return df

if __name__ == "__main__":
    scrape_all()
