import requests

def send_alert(message):
    # Slack webhook
    WEBHOOK_URL = "https://hooks.slack.com/services/XXXX/YYY/ZZZ"
    payload = {"text": message}

    try:
        requests.post(WEBHOOK_URL, json=payload)
        print("ALERT SENT")
    except:
        print("ALERT FAILED")
