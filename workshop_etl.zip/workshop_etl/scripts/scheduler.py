import schedule
import time
import logging
from scrape_hcpcs import scrape_all
from transform_hcpcs import transform
from load_hcpcs import load
from validate_hcpcs import validate

logging.basicConfig(filename="logs/pipeline.log", level=logging.INFO)

def pipeline():
    logging.info("Starting pipeline")
    scrape_all()
    transform()
    load()
    validate()
    logging.info("Pipeline completed")

schedule.every().day.at("10:00").do(pipeline)

if __name__ == "__main__":
    print("Scheduler started…")
    while True:
        schedule.run_pending()
        time.sleep(1)
