-- 1. Count number of codes in each group
SELECT group_code, COUNT(*) 
FROM hcpcs_codes
GROUP BY group_code
ORDER BY group_code;

-- 2. Top 5 categories with most codes
SELECT category_name, COUNT(*) AS total
FROM hcpcs_codes
GROUP BY category_name
ORDER BY total DESC
LIMIT 5;

-- 3. Codes with changed descriptions
SELECT hcpcs_code, COUNT(DISTINCT long_description) AS versions
FROM hcpcs_codes
GROUP BY hcpcs_code
HAVING COUNT(DISTINCT long_description) > 1
ORDER BY versions DESC;

-- 4. Active in 2022 but expired before 2024
SELECT *
FROM hcpcs_codes
WHERE effective_date < '2023-01-01'
  AND end_date < '2024-01-01';
