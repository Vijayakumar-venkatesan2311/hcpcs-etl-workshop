CREATE TABLE IF NOT EXISTS hcpcs_codes (
    id BIGSERIAL PRIMARY KEY,
    group_code CHAR(1) NOT NULL,
    category_name VARCHAR(255) NOT NULL,
    hcpcs_code VARCHAR(10) NOT NULL,
    long_description TEXT NOT NULL,
    effective_date DATE DEFAULT CURRENT_DATE,
    end_date DATE
);

-- History logic: end previous version when description changes
