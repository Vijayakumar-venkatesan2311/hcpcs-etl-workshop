from scripts.scrape_hcpcs import scrape_all
from scripts.transform_hcpcs import transform
from scripts.load_hcpcs import load
from scripts.validate_hcpcs import validate

scrape_all()
transform()
load()
validate()
